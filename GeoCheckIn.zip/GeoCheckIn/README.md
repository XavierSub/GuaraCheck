# GeoCheckIn · UniCerrado

Presença acadêmica por geolocalização (geofencing). FastAPI + SQLAlchemy.

## Rodar localmente
Windows: dê dois cliques em `run.bat` (ou `./run.ps1`). Abra http://localhost:8000
(o GPS do navegador só funciona em `localhost` ou HTTPS).

## Estrutura
- `app.py` – API, modelos, Haversine, autenticação
- `web/index.html` – telas de aluno e professor
- `.env.example` – variáveis de configuração
- `render.yaml` – deploy automático no Render
